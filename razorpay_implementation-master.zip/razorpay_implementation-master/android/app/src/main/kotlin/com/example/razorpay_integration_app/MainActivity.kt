package com.example.razorpay_integration_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
